# SkyGifts — como colocar o site no ar

Três arquivos:

- `index.html` — o site inteiro (loja, personalização, dados, revisão, PDF e envio)
- `apps-script/Codigo.gs` — o recebedor de pedidos, que roda na sua conta Google
- este guia

---

## 1. Ajuste o bloco de configuração

Abra `index.html` e edite só o trecho marcado como `CONFIGURAÇÃO`, logo no começo do `<script>`:

```js
const CONFIG = {
  whatsapp: "5519999999999",   // seu número: 55 + DDD + número, só dígitos
  endpoint: "",                // preencha no passo 5
  precos: { 1: 1490, ... },    // valores em CENTAVOS (1490 = R$ 14,90)
  geometria: "A",              // "A" foto 40×40 mm | "B" foto 44×36 mm
  maxCaracteres: 40,
  painelTesteVisivel: false,   // true mostra o painel de formato/medidas
  folha: { colunas: 3, linhas: 5, calha: 4, margemX: 26, margemY: 16 }
};
```

Enquanto `endpoint` estiver vazio, o site funciona normalmente, mas o pedido não é enviado sozinho: a cliente baixa o PDF e manda pelo WhatsApp.

O painel de teste também pode ser aberto a qualquer momento pelo link "Painel de teste" no rodapé.

---

## 2. Crie a pasta no Google Drive

1. No Drive, crie uma pasta chamada `SkyGifts - Pedidos`.
2. Abra a pasta e copie o **ID** da URL. Em `drive.google.com/drive/folders/1AbC...XyZ`, o ID é o `1AbC...XyZ`.

## 3. Crie a planilha de pedidos

1. Crie uma planilha em branco chamada `SkyGifts - Pedidos`.
2. Copie o **ID** da URL. Em `docs.google.com/spreadsheets/d/1AbC...XyZ/edit`, o ID é o `1AbC...XyZ`.
3. Não precisa criar colunas: o script cria a aba `Pedidos` com os títulos no primeiro pedido.

## 4. Publique o recebedor

1. Vá em `script.google.com` e crie um projeto novo, chamado `SkyGifts`.
2. Apague o conteúdo do arquivo e cole todo o `Codigo.gs`.
3. Preencha as três constantes do topo: ID da pasta, ID da planilha e seu e-mail.
4. Salve.
5. Clique em **Implantar → Nova implantação → Tipo: app da Web**, com:
   - Executar como: **Eu**
   - Quem pode acessar: **Qualquer pessoa**
6. Autorize o acesso quando o Google pedir. Vai aparecer um aviso de "app não verificado": é o seu próprio script, siga em **Avançado → Acessar SkyGifts**.
7. Copie a **URL do app da Web** (termina em `/exec`).

## 5. Ligue o site ao recebedor

Cole a URL do passo 4 em `endpoint`, dentro do `CONFIG`:

```js
endpoint: "https://script.google.com/macros/s/AKfy.../exec",
```

Teste abrindo o `index.html` no seu computador e fazendo um pedido de 1 ímã. Devem acontecer três coisas: o PDF aparece no Drive, a linha aparece na planilha e o e-mail chega para você.

> Sempre que editar o `Codigo.gs`, crie uma **nova versão** da implantação (**Implantar → Gerenciar implantações → editar → Versão: nova**), senão a URL continua rodando o código antigo.

---

## 6. Publique o site no GitHub Pages

1. Crie um repositório no GitHub (pode ser público, já que não há nenhuma senha no código).
2. Envie o `index.html` para a raiz do repositório.
3. Vá em **Settings → Pages**, escolha a branch `main` e a pasta `/ (root)`, e salve.
4. Em poucos minutos o site fica no ar em `https://seuusuario.github.io/nome-do-repo/`.
5. Se quiser domínio próprio depois (`skygifts.com.br`), dá para apontar para o GitHub Pages sem mudar nada no código.

O link curto que você coloca na bio do Instagram é esse endereço.

---

## 7. Teste antes de divulgar

- Faça um pedido completo pelo **celular**, com fotos de verdade.
- **Imprima uma folha de produção em 100%** e confira com a régua a barra de 50 mm do rodapé. Se não der 50 mm, a impressora está reduzindo a escala.
- Corte uma peça e compare com a prévia da tela. É aqui que você decide entre o formato A e o B.
- Teste também com o WhatsApp: clique em "Avisar no WhatsApp" e veja se a mensagem chega certinha.

---

## Como o pedido chega até você

1. A cliente personaliza as fotos no site.
2. O navegador dela monta as peças em 300 dpi e gera o PDF (capa, conferência e folhas A4 com linhas de corte).
3. O PDF vai para o seu Apps Script, que salva no Drive, registra na planilha e te envia por e-mail.
4. A cliente vê o número do pedido, pode baixar o PDF e tem um botão que abre o WhatsApp com a mensagem já escrita.
5. Você responde combinando pagamento e frete, e atualiza a coluna `Status` da planilha.

Se o envio automático falhar (internet ruim, por exemplo), o site baixa o PDF no aparelho dela e mostra o botão do WhatsApp. O pedido não se perde.

---

## Limites e cuidados

- **Tamanho do PDF:** cada peça tem cerca de 100 KB. Acima de 20 MB (pedidos muito grandes), o envio automático é pulado e o site cai direto no caminho do WhatsApp.
- **Contra robôs:** o formulário tem um campo invisível e o script aceita no máximo 20 pedidos por hora. Se um dia você precisar de mais, mude `LIMITE_POR_HORA`.
- **Envio de e-mail:** contas Gmail comuns têm um limite diário de envios do Apps Script. Para o volume inicial, sobra.
- **Fotos e LGPD:** as fotos das clientes ficam dentro do PDF, na sua pasta do Drive. Mantenha a pasta privada e apague os pedidos antigos de tempos em tempos. Se uma cliente pedir para apagar, é só excluir o PDF e a linha da planilha.
- **As fotos não ficam salvas no navegador:** se a cliente recarregar a página no meio da personalização, precisa escolher as fotos de novo.
- **A frase é impressa como imagem em 300 dpi**, junto com a foto. Fica nítida no tamanho de 5 cm e evita qualquer problema de fonte na hora de imprimir.
