/**
 * SkyGifts — recebedor de pedidos
 * ---------------------------------------------------------------------------
 * O site envia o pedido (dados + PDF) para cá. Este script:
 *   1. salva o PDF numa pasta do seu Google Drive
 *   2. registra uma linha na sua planilha de pedidos
 *   3. envia um e-mail para você com o PDF anexado
 *
 * Preencha as três constantes abaixo e siga o LEIA-ME para publicar.
 */

const PASTA_DRIVE_ID = "COLE_AQUI_O_ID_DA_PASTA";
const PLANILHA_ID = "COLE_AQUI_O_ID_DA_PLANILHA";
const MEU_EMAIL = "seuemail@gmail.com";

const LIMITE_POR_HORA = 20;
const LIMITE_ANEXO_MB = 18;

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) return resposta({ ok: false, erro: "sem dados" });
    const d = JSON.parse(e.postData.contents);

    // Campo invisível no formulário: se veio preenchido, é robô.
    if (d.armadilha) return resposta({ ok: true, ignorado: true });

    if (!d.numero || !d.nome || !d.whatsapp || !d.pdfBase64) return resposta({ ok: false, erro: "dados incompletos" });
    if (!controleDeFluxo()) return resposta({ ok: false, erro: "muitos pedidos seguidos" });

    const blob = Utilities.newBlob(
      Utilities.base64Decode(d.pdfBase64),
      "application/pdf",
      limparNome(d.nomeArquivo || (d.numero + ".pdf"))
    );
    const tamanhoMb = blob.getBytes().length / 1024 / 1024;

    const arquivo = DriveApp.getFolderById(PASTA_DRIVE_ID).createFile(blob);
    const link = arquivo.getUrl();

    registrarNaPlanilha(d, link);
    enviarEmail(d, blob, link, tamanhoMb);

    return resposta({ ok: true, numero: d.numero, link: link });
  } catch (err) {
    return resposta({ ok: false, erro: String(err) });
  }
}

function doGet() {
  return resposta({ ok: true, servico: "SkyGifts", status: "no ar" });
}

function registrarNaPlanilha(d, link) {
  const planilha = SpreadsheetApp.openById(PLANILHA_ID);
  let aba = planilha.getSheetByName("Pedidos");
  if (!aba) {
    aba = planilha.insertSheet("Pedidos");
    aba.appendRow(["Data", "Pedido", "Cliente", "WhatsApp", "Quantidade", "Valor", "Frases", "PDF", "Status"]);
    aba.setFrozenRows(1);
  }
  aba.appendRow([
    new Date(),
    d.numero,
    d.nome,
    "'" + d.whatsapp,
    d.quantidade,
    (d.valorCentavos || 0) / 100,
    (d.frases || []).join(" | "),
    link,
    "Aguardando pagamento"
  ]);
}

function enviarEmail(d, blob, link, tamanhoMb) {
  const frases = (d.frases || []).map(function (f) { return "<li>" + escapar(f) + "</li>"; }).join("");
  const zapLimpo = String(d.whatsapp).replace(/\D/g, "");
  const corpo =
    "<div style=\"font-family:Arial,sans-serif;color:#22324A\">" +
    "<h2 style=\"margin:0 0 4px\">Novo pedido " + escapar(d.numero) + "</h2>" +
    "<p style=\"color:#56657A;margin:0 0 16px\">SkyGifts</p>" +
    "<p><b>Cliente:</b> " + escapar(d.nome) + "<br>" +
    "<b>WhatsApp:</b> " + escapar(d.whatsapp) +
    " &nbsp;(<a href=\"https://wa.me/55" + zapLimpo + "\">abrir conversa</a>)<br>" +
    "<b>Quantidade:</b> " + escapar(String(d.quantidade)) + " ímãs<br>" +
    "<b>Valor dos produtos:</b> R$ " + ((d.valorCentavos || 0) / 100).toFixed(2).replace(".", ",") + " (frete à parte)</p>" +
    "<p><b>Frases:</b></p><ul>" + frases + "</ul>" +
    "<p><a href=\"" + link + "\">Abrir o PDF no Drive</a></p>" +
    "</div>";

  const opcoes = { to: MEU_EMAIL, subject: "Novo pedido " + d.numero + " — " + d.nome, htmlBody: corpo };
  if (tamanhoMb <= LIMITE_ANEXO_MB) opcoes.attachments = [blob];
  MailApp.sendEmail(opcoes);
}

function controleDeFluxo() {
  const cache = CacheService.getScriptCache();
  const chave = "pedidos_" + new Date().getHours();
  const atual = Number(cache.get(chave) || 0);
  if (atual >= LIMITE_POR_HORA) return false;
  cache.put(chave, String(atual + 1), 3600);
  return true;
}

function limparNome(nome) {
  return String(nome).replace(/[\\/:*?"<>|]/g, "-").slice(0, 120);
}

function escapar(t) {
  return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function resposta(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
